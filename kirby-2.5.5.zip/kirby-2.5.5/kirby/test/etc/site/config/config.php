<?php 

c::set('license', 'test');