<?php 

return function($topbar) {
  $topbar->append('', l('error.headline'));
};