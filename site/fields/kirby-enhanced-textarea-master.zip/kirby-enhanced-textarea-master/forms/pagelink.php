<?php 

return function($page, $textarea) {

  $form = new Kirby\Panel\Form();

  return $form;

};